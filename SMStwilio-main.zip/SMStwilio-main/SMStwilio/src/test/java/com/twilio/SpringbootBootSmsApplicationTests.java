package com.twilio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBootSmsApplicationTests {

	@Test
	void contextLoads() {
	}

}

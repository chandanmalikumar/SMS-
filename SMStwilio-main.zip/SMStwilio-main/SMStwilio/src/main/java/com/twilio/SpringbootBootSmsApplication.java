package com.twilio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBootSmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBootSmsApplication.class, args);
	}

}
